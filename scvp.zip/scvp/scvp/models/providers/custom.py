"""CustomModelProvider: run local models without any external API.

Backends
--------
- ``mock``      : deterministic in-memory model (tests / CI / demos).
- ``transformers``: HuggingFace ``transformers`` + ``torch`` (local dir or repo id).
- ``llama_cpp`` : ``llama-cpp-python`` for GGUF weights.
- ``auto``      : picks a backend from ``model_path`` (``.gguf`` -> llama_cpp,
                  otherwise -> transformers).

All heavy imports are lazy, so the package stays importable on machines
without GPU libraries installed.
"""
from __future__ import annotations

import os
import queue
import threading
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from typing import Any, Dict, Iterator, Optional

from ..base import (
    BackendUnavailableError,
    GenerationError,
    ModelLoadError,
    ModelProvider,
    ModelTimeoutError,
)


# --------------------------------------------------------------------------- #
# Mock model: used by tests and as a zero-dependency demo backend.
# --------------------------------------------------------------------------- #
class MockModel:
    """A tiny deterministic model that mimics the real backends' interface.

    It never downloads anything and lets tests control latency and failures.
    """

    def __init__(self, echo_prefix: str = "MOCK RESPONSE:", simulated_latency: float = 0.0):
        self.echo_prefix = echo_prefix
        self.simulated_latency = simulated_latency
        self.calls: list = []

    def generate(self, prompt: str, max_tokens: int = 512, **_kw) -> str:
        self.calls.append(prompt)
        if self.simulated_latency:
            import time
            time.sleep(self.simulated_latency)
        words = f"{self.echo_prefix} {prompt}".split()[:max_tokens]
        return " ".join(words)

    def stream(self, prompt: str, chunk_size: int = 4, **_kw) -> Iterator[str]:
        text = self.generate(prompt)
        for i in range(0, len(text), chunk_size):
            yield text[i:i + chunk_size]


# --------------------------------------------------------------------------- #
# Real backends (thin wrappers around the optional libraries).
# --------------------------------------------------------------------------- #
class _TransformersBackend:
    def __init__(self, model_path: Optional[str], model_name: Optional[str],
                 device: str, **hf_kwargs):
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer  # noqa
        except ImportError as exc:  # pragma: no cover - depends on env
            raise BackendUnavailableError(
                "the 'transformers' backend requires `pip install transformers`"
            ) from exc
        self._AutoModelForCausalLM = AutoModelForCausalLM
        self._AutoTokenizer = AutoTokenizer
        self.model_path, self.model_name = model_path, model_name
        self.device, self.hf_kwargs = device, hf_kwargs

    def load(self):
        src = self.model_path or self.model_name
        if self.model_path and not os.path.exists(self.model_path):
            raise ModelLoadError(f"model path does not exist: {self.model_path}")
        device_map = "auto" if self.device == "auto" else None
        tok = self._AutoTokenizer.from_pretrained(src)
        model = self._AutoModelForCausalLM.from_pretrained(
            src, device_map=device_map,
            **({"low_cpu_mem_usage": True} if device_map else {}),
            **self.hf_kwargs,
        )
        if self.device not in ("auto", "cpu", "mps") and hasattr(model, "to"):
            model = model.to(self.device)
        return tok, model

    @staticmethod
    def generate(tok, model, prompt, max_tokens, temperature, **_kw):
        import torch
        enc = tok(prompt, return_tensors="pt")
        if hasattr(model, "device") and str(model.device) != "cpu":
            enc = {k: v.to(model.device) for k, v in enc.items()}
        with torch.no_grad():
            out = model.generate(
                **enc,
                max_new_tokens=max_tokens,
                do_sample=temperature > 0,
                temperature=max(temperature, 1e-5),
                pad_token_id=tok.eos_token_id,
            )
        new_tokens = out[0][enc["input_ids"].shape[1]:]
        return tok.decode(new_tokens, skip_special_tokens=True)

    @staticmethod
    def stream(tok, model, prompt, max_tokens, temperature, **_kw):
        from transformers import TextIteratorStreamer
        import torch
        enc = tok(prompt, return_tensors="pt")
        streamer = TextIteratorStreamer(tok, skip_special_tokens=True)
        kwargs = dict(
            **enc, max_new_tokens=max_tokens,
            do_sample=temperature > 0, temperature=max(temperature, 1e-5),
            pad_token_id=tok.eos_token_id, streamer=streamer,
        )
        thread = threading.Thread(target=model.generate, kwargs=kwargs, daemon=True)
        thread.start()
        yield from streamer


class _LlamaCppBackend:
    def __init__(self, model_path: str, **_kw):
        try:
            from llama_cpp import Llama  # noqa
        except ImportError as exc:  # pragma: no cover - depends on env
            raise BackendUnavailableError(
                "the 'llama_cpp' backend requires `pip install llama-cpp-python`"
            ) from exc
        self._Llama = Llama
        self.model_path = model_path

    def load(self):
        if not os.path.exists(self.model_path):
            raise ModelLoadError(f"model path does not exist: {self.model_path}")
        return self._Llama(model_path=self.model_path, verbose=False)

    @staticmethod
    def _prompt(prompt: str) -> str:
        return f"<|user|>\n{prompt}<|end|>\n<|assistant|>\n"

    def generate(self, model, prompt, max_tokens, temperature, **_kw):
        out = model.create_completion(
            prompt=self._prompt(prompt), max_tokens=max_tokens,
            temperature=temperature, stream=False,
        )
        return out["choices"][0]["text"].strip()

    def stream(self, model, prompt, max_tokens, temperature, **_kw):
        for chunk in model.create_completion(
            prompt=self._prompt(prompt), max_tokens=max_tokens,
            temperature=temperature, stream=True,
        ):
            yield chunk["choices"][0]["text"]


# --------------------------------------------------------------------------- #
# The provider itself.
# --------------------------------------------------------------------------- #
class CustomModelProvider(ModelProvider):
    """Local model provider — no API key, no external service.

    Config keys (all optional unless noted):
        model_path   : local directory/file of the model weights.
        model_name   : HuggingFace repo id (alternative to model_path).
        backend      : auto | mock | transformers | llama_cpp (default: auto).
        device       : auto | cpu | cuda | mps (default: auto).
        temperature  : float (default 0.7).
        max_tokens   : int   (default 512).
        timeout_seconds : load AND generate timeout (default 120).
        stream       : whether stream() should chunk (default True).
    """

    DEFAULTS: Dict[str, Any] = {
        "backend": "auto",
        "device": "auto",
        "temperature": 0.7,
        "max_tokens": 512,
        "timeout_seconds": 120,
        "stream": True,
    }

    def __init__(self, name: str = "custom", config: Optional[Dict[str, Any]] = None,
                 model: Optional[Any] = None) -> None:
        merged = dict(self.DEFAULTS)
        merged.update(config or {})
        super().__init__(name, merged)
        # `model` allows tests / power users to inject a pre-built model
        # (e.g. MockModel) and skip loading entirely.
        self._model = model
        self._backend = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"{name}-gen")

    # -- configuration -------------------------------------------------- #
    @property
    def backend_name(self) -> str:
        backend = self.config["backend"]
        if backend != "auto":
            return backend
        path = self.config.get("model_path") or ""
        return "llama_cpp" if path.lower().endswith(".gguf") else "transformers"

    @property
    def timeout(self) -> float:
        return float(self.config.get("timeout_seconds", 120))

    # -- loading -------------------------------------------------------- #
    def _resolve_backend(self):
        name = self.backend_name
        if name == "mock":
            return None  # MockModel needs no backend wrapper
        if name == "llama_cpp":
            return _LlamaCppBackend(self.config["model_path"])
        if name == "transformers":
            return _TransformersBackend(
                self.config.get("model_path"), self.config.get("model_name"),
                self.config.get("device", "auto"),
            )
        raise BackendUnavailableError(f"unknown backend: {name!r}")

    def load(self) -> "CustomModelProvider":
        """Eagerly load the model (otherwise it loads lazily on first use)."""
        self._ensure_loaded()
        return self

    def _ensure_loaded(self):
        if self._model is not None:
            return
        # فحص المسار أولًا — قبل بناء الـ backend (الذي يستورد المكتبة)
        path = self.config.get("model_path")
        if path and self.backend_name != "mock" and not os.path.exists(path):
            raise ModelLoadError(f"model path does not exist: {path}")
        self._backend = self._resolve_backend()
        future = self._executor.submit(self._backend.load)
        try:
            self._model = future.result(timeout=self.timeout)
        except FuturesTimeout as exc:
            raise ModelTimeoutError(
                f"loading model timed out after {self.timeout}s"
            ) from exc
        except (BackendUnavailableError, ModelLoadError):
            raise
        except Exception as exc:
            raise ModelLoadError(f"failed to load model: {exc}") from exc

    def health_check(self) -> bool:
        try:
            self._ensure_loaded()
        except Exception:
            return False
        return self._model is not None

    # -- generation ----------------------------------------------------- #
    def _run_with_timeout(self, fn, *args, **kwargs):
        future = self._executor.submit(fn, *args, **kwargs)
        try:
            return future.result(timeout=self.timeout)
        except FuturesTimeout as exc:
            raise ModelTimeoutError(
                f"generation timed out after {self.timeout}s"
            ) from exc
        except (ModelLoadError, ModelTimeoutError, BackendUnavailableError):
            raise
        except Exception as exc:
            raise GenerationError(f"generation failed: {exc}") from exc

    def generate(self, prompt: str, **kwargs) -> str:
        self._ensure_loaded()
        gen_kw = dict(
            max_tokens=int(kwargs.get("max_tokens", self.config["max_tokens"])),
            temperature=float(kwargs.get("temperature", self.config["temperature"])),
        )
        if isinstance(self._model, MockModel):
            return self._model.generate(prompt, **gen_kw)

        backend = self._backend
        if isinstance(backend, _LlamaCppBackend):
            return self._run_with_timeout(backend.generate, self._model, prompt, **gen_kw)
        # transformers
        tok, hf_model = self._model
        return self._run_with_timeout(
            lambda: backend.generate(tok, hf_model, prompt, **gen_kw)
        )

    def stream(self, prompt: str, **kwargs) -> Iterator[str]:
        self._ensure_loaded()
        gen_kw = dict(
            max_tokens=int(kwargs.get("max_tokens", self.config["max_tokens"])),
            temperature=float(kwargs.get("temperature", self.config["temperature"])),
        )
        if not self.config.get("stream", True):
            yield self.generate(prompt, **kwargs)
            return

        if isinstance(self._model, MockModel):
            yield from self._model.stream(prompt, **gen_kw)
            return

        backend = self._backend
        iterator: Iterator[str]
        if isinstance(backend, _LlamaCppBackend):
            iterator = backend.stream(self._model, prompt, **gen_kw)
        else:
            tok, hf_model = self._model
            iterator = backend.stream(tok, hf_model, prompt, **gen_kw)
        # Safety net: surface backend exceptions as GenerationError to the consumer.
        try:
            yield from iterator
        except GenerationError:
            raise
        except Exception as exc:
            raise GenerationError(f"streaming failed: {exc}") from exc

    def close(self) -> None:
        self._model = None
        self._executor.shutdown(wait=False, cancel_futures=True)
