"""Abstract interface that every model provider must implement."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Iterator, Optional


class ProviderError(Exception):
    """Base class for all provider-related errors."""


class BackendUnavailableError(ProviderError):
    """Raised when the required backend library is not installed."""


class ModelLoadError(ProviderError):
    """Raised when the model fails to load from the given path."""


class ModelTimeoutError(ProviderError):
    """Raised when loading or generation exceeds the configured timeout."""


class GenerationError(ProviderError):
    """Raised when text generation fails."""


class ModelProvider(ABC):
    """Base class for all model providers.

    Implementations must be constructible from a plain config dict and
    must not require any external API key.
    """

    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None) -> None:
        self.name = name
        self.config: Dict[str, Any] = dict(config or {})

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """Return the full generated response for ``prompt``."""

    def stream(self, prompt: str, **kwargs) -> Iterator[str]:
        """Yield response chunks.

        The default implementation simply yields the full response once;
        providers with native streaming should override this method.
        """
        yield self.generate(prompt, **kwargs)

    def health_check(self) -> bool:
        """Return True when the provider is ready to serve requests."""
        return True

    def close(self) -> None:
        """Release any resources held by the provider."""
