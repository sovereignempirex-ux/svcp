"""Provider registry: maps provider ``type`` names to factory callables."""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from .base import ModelProvider, ProviderError

Factory = Callable[[str, Dict[str, Any]], ModelProvider]


class ProviderNotRegisteredError(ProviderError):
    """Raised when a provider type is not present in the registry."""


class ProviderRegistry:
    """A small, explicit registry for model providers.

    Usage::

        registry = ProviderRegistry.with_builtin_providers()
        provider = registry.create("custom", config_dict)
    """

    def __init__(self) -> None:
        self._factories: Dict[str, Factory] = {}

    def register(self, provider_type: str, factory: Factory, *, override: bool = False) -> None:
        if provider_type in self._factories and not override:
            raise ValueError(f"provider type already registered: {provider_type!r}")
        self._factories[provider_type] = factory

    def register_provider(self, provider_type: str):
        """Class/decorator helper: ``@registry.register_provider("custom")``."""
        def decorator(cls):
            self.register(provider_type, lambda name, cfg: cls(name, cfg))
            return cls
        return decorator

    def create(self, provider_type: str, name: Optional[str] = None,
               config: Optional[Dict[str, Any]] = None) -> ModelProvider:
        if provider_type not in self._factories:
            raise ProviderNotRegisteredError(
                f"provider type {provider_type!r} is not registered. "
                f"Available: {sorted(self._factories)}"
            )
        return self._factories[provider_type](name or provider_type, config or {})

    def list_providers(self) -> List[str]:
        return sorted(self._factories)

    @classmethod
    def with_builtin_providers(cls) -> "ProviderRegistry":
        """Build a registry pre-loaded with the built-in providers."""
        registry = cls()
        # Imported lazily to avoid heavy optional dependencies at import time.
        from .providers.custom import CustomModelProvider
        registry.register("custom", lambda name, cfg: CustomModelProvider(name, cfg))
        return registry
