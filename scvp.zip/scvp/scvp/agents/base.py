"""Minimal agent abstraction bound to a model provider."""
from __future__ import annotations

from typing import Any, Dict, Iterator, Optional

from scvp.models.base import ModelProvider


class Agent:
    """An agent = a role (system prompt) + a model provider.

    The agent only talks to the :class:`ModelProvider` interface, so any
    registered provider (local custom model, future external ones, ...) works.
    """

    def __init__(self, name: str, provider: ModelProvider,
                 system_prompt: Optional[str] = None) -> None:
        self.name = name
        self.provider = provider
        self.system_prompt = system_prompt or "You are a helpful assistant."
        self.history = []

    def _build_prompt(self, task: str) -> str:
        return f"{self.system_prompt}\n\nUser: {task}\nAssistant:"

    def run(self, task: str, **kwargs) -> str:
        prompt = self._build_prompt(task)
        response = self.provider.generate(prompt, **kwargs)
        self.history.append({"role": "user", "content": task})
        self.history.append({"role": "assistant", "content": response})
        return response

    def stream(self, task: str, **kwargs) -> Iterator[str]:
        prompt = self._build_prompt(task)
        full = []
        for chunk in self.provider.stream(prompt, **kwargs):
            full.append(chunk)
            yield chunk
        self.history.append({"role": "user", "content": task})
        self.history.append({"role": "assistant", "content": "".join(full)})
