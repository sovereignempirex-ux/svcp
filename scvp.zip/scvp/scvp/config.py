"""YAML configuration loading for SCVP."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import yaml


class ConfigError(Exception):
    """Raised when the configuration file is missing or invalid."""


@dataclass
class ProviderConfig:
    """Typed view of a single ``models.providers.<name>`` section."""

    name: str
    type: str
    options: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"type": self.type, **self.options}


@dataclass
class ModelsConfig:
    """Typed view of the whole ``models:`` block."""

    default: str
    providers: Dict[str, ProviderConfig]

    def get_provider(self, name: Optional[str] = None) -> ProviderConfig:
        key = name or self.default
        if key not in self.providers:
            raise ConfigError(
                f"provider {key!r} not found in config; "
                f"available: {sorted(self.providers)}"
            )
        return self.providers[key]

    def list_providers(self) -> List[str]:
        return sorted(self.providers)


def load_config(path: str) -> ModelsConfig:
    """Read a YAML file and return a validated :class:`ModelsConfig`."""
    if not os.path.exists(path):
        raise ConfigError(f"config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}
    models = raw.get("models")
    if not isinstance(models, dict):
        raise ConfigError("config must contain a 'models:' mapping")

    default = models.get("default")
    providers_raw = models.get("providers") or {}
    providers: Dict[str, ProviderConfig] = {}
    for name, section in providers_raw.items():
        if not isinstance(section, dict) or "type" not in section:
            raise ConfigError(
                f"provider {name!r} must be a mapping with a 'type' key"
            )
        ptype = section["type"]
        options = {k: v for k, v in section.items() if k != "type"}
        providers[name] = ProviderConfig(name=name, type=ptype, options=options)

    if not providers:
        raise ConfigError("config must define at least one provider")
    if not default:
        default = next(iter(providers))
    if default not in providers:
        raise ConfigError(f"default provider {default!r} is not defined")

    return ModelsConfig(default=default, providers=providers)
