"""Runtime: wires configuration + registry + agents into one entry point."""
from __future__ import annotations

from typing import Dict, Optional

from scvp.agents.base import Agent
from scvp.config import ModelsConfig, ProviderConfig, load_config
from scvp.models.base import ModelProvider
from scvp.models.registry import ProviderRegistry


class Runtime:
    """Loads config, instantiates providers through the registry, and
    exposes ready-to-use agents.

    Usage::

        with Runtime.from_config("config.yaml") as rt:
            answer = rt.run("what is 2+2?")
    """

    def __init__(self, config: ModelsConfig,
                 registry: Optional[ProviderRegistry] = None) -> None:
        self.config = config
        self.registry = registry or ProviderRegistry.with_builtin_providers()
        self._providers: Dict[str, ModelProvider] = {}

    @classmethod
    def from_config(cls, path: str,
                    registry: Optional[ProviderRegistry] = None) -> "Runtime":
        return cls(load_config(path), registry)

    # -- providers ------------------------------------------------------ #
    def get_provider(self, name: Optional[str] = None) -> ModelProvider:
        cfg: ProviderConfig = self.config.get_provider(name)
        if cfg.name not in self._providers:
            self._providers[cfg.name] = self.registry.create(
                cfg.type, name=cfg.name, config=cfg.to_dict()
            )
        return self._providers[cfg.name]

    # -- agents --------------------------------------------------------- #
    def create_agent(self, name: str = "assistant",
                     provider: Optional[str] = None,
                     system_prompt: Optional[str] = None) -> Agent:
        return Agent(name=name, provider=self.get_provider(provider),
                     system_prompt=system_prompt)

    def run(self, task: str, provider: Optional[str] = None, **kwargs) -> str:
        return self.get_provider(provider).generate(task, **kwargs)

    # -- lifecycle ------------------------------------------------------ #
    def close(self) -> None:
        for provider in self._providers.values():
            provider.close()
        self._providers.clear()

    def __enter__(self) -> "Runtime":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
