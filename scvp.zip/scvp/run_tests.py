#!/usr/bin/env python3
"""Run the test suite WITHOUT requiring pytest.

If pytest is installed it is used; otherwise a tiny compatibility shim
provides just enough of the pytest API (`raises`, `mark.skipif`, `tmp_path`)
for this suite. Usage: python run_tests.py
"""
import importlib.util
import pathlib
import sys
import tempfile
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def _run_with_pytest():
    import pytest
    sys.exit(pytest.main(["-q", str(ROOT / "tests")]))


def _install_pytest_shim():
    import types
    shim = types.ModuleType("pytest")

    class RaisesContext:
        def __init__(self, exc):
            self.exc = exc
            self.value = None
        def __enter__(self):
            return self
        def __exit__(self, et, ev, tb):
            if et is None:
                raise AssertionError(f"DID NOT RAISE {self.exc.__name__}")
            if issubclass(et, self.exc):
                self.value = ev
                return True
            return False

    def raises(exc):
        return RaisesContext(exc)

    class _Mark:
        def skipif(self, condition, reason=""):
            def deco(fn):
                if condition:
                    fn.__skip_reason__ = reason
                return fn
            return deco

    shim.raises = raises
    shim.mark = _Mark()
    shim.skip = type("Skip", (Exception,), {})
    sys.modules["pytest"] = shim


def _run_with_shim():
    import types
    _install_pytest_shim()
    test_dir = ROOT / "tests"
    passed = failed = skipped = 0
    failures = []
    for path in sorted(test_dir.glob("test_*.py")):
        mod = types.ModuleType(path.stem)
        mod.__file__ = str(path)
        try:
            exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"),
                 mod.__dict__)
        except Exception:
            failed += 1
            failures.append((path.stem, "<import>", traceback.format_exc()))
            continue
        for attr in sorted(dir(mod)):
            if not attr.startswith("test_"):
                continue
            fn = getattr(mod, attr)
            if not callable(fn):
                continue
            reason = getattr(fn, "__skip_reason__", None)
            if reason:
                skipped += 1
                print(f"SKIP  {path.stem}::{attr}  ({reason})")
                continue
            try:
                import inspect
                kwargs = {}
                if "tmp_path" in inspect.signature(fn).parameters:
                    tmp = tempfile.mkdtemp(prefix=f"{attr}-")
                    kwargs["tmp_path"] = pathlib.Path(tmp)
                fn(**kwargs)
                passed += 1
                print(f"PASS  {path.stem}::{attr}")
            except Exception:
                failed += 1
                failures.append((path.stem, attr, traceback.format_exc()))
                print(f"FAIL  {path.stem}::{attr}")
    print("-" * 60)
    for stem, attr, tb in failures:
        print(f"\n### FAILURE: {stem}::{attr}\n{tb}")
    print(f"\n{passed} passed, {failed} failed, {skipped} skipped")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    if importlib.util.find_spec("pytest"):
        _run_with_pytest()
    else:
        print("pytest not found -> using built-in shim runner\n")
        _run_with_shim()
