"""Provider behaviour tests using the injected MockModel (no heavy weights)."""
import pytest

from scvp.models.base import ModelProvider
from scvp.models.providers import CustomModelProvider, MockModel


def _provider(**cfg):
    return CustomModelProvider("custom", cfg, model=MockModel())


def test_is_a_model_provider():
    assert isinstance(_provider(), ModelProvider)


def test_generate_returns_mock_response():
    p = _provider(max_tokens=8)
    out = p.generate("hello world this is a test")
    assert out.startswith("MOCK RESPONSE:")
    assert len(out.split()) <= 8  # max_tokens respected


def test_generate_uses_config_temperature_default():
    mock = MockModel()
    p = CustomModelProvider("custom", {"temperature": 0.2, "backend": "mock"}, model=mock)
    assert p.generate("hi")  # goes through the MockModel path
    assert mock.calls == ["hi"]


def test_stream_yields_chunks_and_reconstructs_text():
    p = _provider()
    full = "".join(p.stream("hello world"))
    assert full == p.generate("hello world")
    assert len(list(p.stream("hello world"))) > 1  # actually chunked


def test_stream_disabled_falls_back_to_single_yield():
    p = _provider(stream=False)
    chunks = list(p.stream("hello"))
    assert len(chunks) == 1


def test_lazy_loading_injects_model_without_files():
    # لا ملفات على الإطلاق — التحميل تم عبر الحقن ولا يُطلب backend.
    p = CustomModelProvider("custom", {"backend": "auto", "model_path": "/nonexistent"})
    p._model = MockModel()  # simulate injection before first use
    assert p.generate("hi").startswith("MOCK RESPONSE:")
