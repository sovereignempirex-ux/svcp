"""Error-handling tests: bad paths, timeouts, unknown backends."""
import importlib.util

import pytest

from scvp.models.base import (
    BackendUnavailableError,
    ModelLoadError,
    ModelTimeoutError,
)
from scvp.models.providers import CustomModelProvider, MockModel


def test_missing_model_path_raises_model_load_error(tmp_path):
    p = CustomModelProvider("custom", {
        "backend": "transformers",
        "model_path": str(tmp_path / "missing-dir"),
        "timeout_seconds": 5,
    })
    with pytest.raises(ModelLoadError):
        p.load()


def test_gguf_missing_path_raises_model_load_error(tmp_path):
    p = CustomModelProvider("custom", {
        "backend": "llama_cpp",
        "model_path": str(tmp_path / "missing.gguf"),
        "timeout_seconds": 5,
    })
    with pytest.raises(ModelLoadError):
        p.load()


def test_unknown_backend_raises():
    p = CustomModelProvider("custom", {"backend": "not-a-backend"})
    with pytest.raises(BackendUnavailableError):
        p.load()


@pytest.mark.skipif(
    importlib.util.find_spec("transformers") is not None,
    reason="transformers installed -> the real (heavy) backend would load",
)
def test_transformers_backend_reports_missing_library(tmp_path):
    p = CustomModelProvider("custom", {
        "backend": "transformers",
        "model_name": "any/model",
        "timeout_seconds": 5,
    })
    with pytest.raises(BackendUnavailableError):
        p.load()


def test_load_timeout_raises():
    # MockModel بزمن تأخير أكبر من المهمة المسموحة.
    slow = MockModel(simulated_latency=2.0)
    p = CustomModelProvider("custom", {"timeout_seconds": 0.2}, model=slow)
    # استدعاء generate مع mock لا يمرّر عبر الـ executor؛ نختبر المسار الحقيقي عبر _run_with_timeout
    with pytest.raises(ModelTimeoutError):
        p._run_with_timeout(slow.generate, "hi")


def test_health_check_false_on_broken_provider(tmp_path):
    p = CustomModelProvider("custom", {
        "backend": "transformers",
        "model_path": str(tmp_path / "missing"),
        "timeout_seconds": 5,
    })
    assert p.health_check() is False
