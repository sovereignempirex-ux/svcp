"""Registration tests: the registry is the single source of truth."""
import pytest

from scvp.models.base import ModelProvider
from scvp.models.providers import CustomModelProvider
from scvp.models.registry import (
    ProviderNotRegisteredError,
    ProviderRegistry,
)


def test_custom_provider_is_registered():
    registry = ProviderRegistry.with_builtin_providers()
    assert "custom" in registry.list_providers()


def test_create_custom_provider():
    registry = ProviderRegistry.with_builtin_providers()
    provider = registry.create("custom", config={"backend": "mock"})
    assert isinstance(provider, CustomModelProvider)
    assert provider.name == "custom"


def test_unknown_provider_raises():
    registry = ProviderRegistry()
    with pytest.raises(ProviderNotRegisteredError):
        registry.create("does-not-exist")


def test_duplicate_registration_rejected():
    registry = ProviderRegistry()
    registry.register("a", lambda n, c: None)
    with pytest.raises(ValueError):
        registry.register("a", lambda n, c: None)
    registry.register("a", lambda n, c: None, override=True)  # allowed


def test_register_provider_decorator():
    class Dummy(ModelProvider):
        def generate(self, prompt, **kw):
            return "ok"

    registry = ProviderRegistry()
    registry.register_provider("dummy")(Dummy)
    assert registry.create("dummy").generate("hi") == "ok"
