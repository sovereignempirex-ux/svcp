"""Configuration loading tests."""
import pytest

from scvp.config import ConfigError, load_config

VALID = """
models:
  default: custom
  providers:
    custom:
      type: custom
      model_path: "./models/my-model.gguf"
      device: "auto"
      temperature: 0.7
      max_tokens: 512
"""


def _write(tmp_path, text):
    p = tmp_path / "config.yaml"
    p.write_text(text, encoding="utf-8")
    return str(p)


def test_load_valid_config(tmp_path):
    cfg = load_config(_write(tmp_path, VALID))
    assert cfg.default == "custom"
    assert cfg.list_providers() == ["custom"]
    prov = cfg.get_provider()
    assert prov.type == "custom"
    assert prov.options["model_path"] == "./models/my-model.gguf"
    assert prov.options["max_tokens"] == 512


def test_get_named_provider(tmp_path):
    cfg = load_config(_write(tmp_path, VALID))
    assert cfg.get_provider("custom").name == "custom"


def test_missing_file_raises(tmp_path):
    with pytest.raises(ConfigError):
        load_config(str(tmp_path / "nope.yaml"))


def test_missing_models_block_raises(tmp_path):
    with pytest.raises(ConfigError):
        load_config(_write(tmp_path, "other: 1\n"))


def test_provider_without_type_raises(tmp_path):
    bad = "models:\n  providers:\n    x:\n      model_path: m\n"
    with pytest.raises(ConfigError):
        load_config(_write(tmp_path, bad))


def test_unknown_default_raises(tmp_path):
    bad = "models:\n  default: ghost\n  providers:\n    a:\n      type: custom\n"
    with pytest.raises(ConfigError):
        load_config(_write(tmp_path, bad))
