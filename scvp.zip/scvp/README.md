# SCVP — CustomModelProvider

مشغّل موديلات محلي (Local-first) بلا API key وبلا خدمات خارجية،
مبني على بنية providers / agents / runtime / config / tests.

## البنية

```
scvp/
├── scvp/
│   ├── config.py                    # تحميل YAML → ModelsConfig / ProviderConfig
│   ├── runtime.py                   # Runtime: يربط config + registry + agents
│   ├── models/
│   │   ├── base.py                  # ModelProvider (ABC) + شجرة أخطاء ProviderError
│   │   ├── registry.py              # ProviderRegistry: register/create/list
│   │   └── providers/
│   │       └── custom.py            # CustomModelProvider + MockModel
│   └── agents/base.py               # Agent = system_prompt + provider
├── tests/                           # 4 ملفات اختبار (لا تحمّل موديلًا حقيقيًا)
├── config.yaml                      # مثال إعدادات جاهز
└── run_tests.py                     # شغّل الاختبارات حتى بدون pytest
```

## التثبيت

```bash
pip install pyyaml                 # إلزامي
pip install torch transformers     # لموديلات HuggingFace
pip install llama-cpp-python       # لموديلات GGUF (أخف على CPU)
pip install pytest                 # اختياري — يوجد runner بديل مدمج
```

## اختيار الـ backend

| القيمة | متى تستخدمها |
|--------|--------------|
| `auto` (افتراضي) | ملف `.gguf` → llama_cpp، غير ذلك → transformers |
| `transformers` | مجلد موديل محلي أو معرف HuggingFace (`model_name`) |
| `llama_cpp` | ملف أوزان GGUF واحد |
| `mock` | بدون أي تحميل — للاختبارات والتجارب السريعة |

## تحميل موديل محلي

- **GGUF:** نزّل ملف `.gguf` (من HuggingFace مثلًا) إلى `./models/`
- **HuggingFace:** مسار مجلد محلي (بعد `save_pretrained`) أو معرف مستودع مثل
  `HuggingFaceTB/SmolLM2-135M-Instruct` (يُحمّل مرة واحدة ثم يعمل محليًا)

## الإعدادات (config.yaml)

```yaml
models:
  default: custom
  providers:
    custom:
      type: custom
      backend: auto            # auto | mock | transformers | llama_cpp
      model_path: "./models/my-model.gguf"
      # model_name: "HuggingFaceTB/SmolLM2-135M-Instruct"  # بديل عن model_path
      device: "auto"           # auto | cpu | cuda | mps
      temperature: 0.7
      max_tokens: 512
      timeout_seconds: 120
      stream: true
```

## التشغيل

```python
from scvp import Runtime

with Runtime.from_config("config.yaml") as rt:
    # مباشرة عبر الـ default provider
    print(rt.run("ما عاصمة مصر؟"))

    # عبر Agent
    agent = rt.create_agent("مساعد", system_prompt="أجب بالعربية باختصار.")
    print(agent.run("اشرح الذكاء الاصطناعي في سطرين"))

    # streaming
    for chunk in agent.stream("اكتب قصيدة قصيرة"):
        print(chunk, end="", flush=True)
```

أو بدون YAML:

```python
from scvp.models.providers import CustomModelProvider

provider = CustomModelProvider("custom", {
    "backend": "llama_cpp",
    "model_path": "./models/my-model.gguf",
    "temperature": 0.7,
    "max_tokens": 512,
})
print(provider.generate("مرحبًا"))
```

## الاختبارات

```bash
python run_tests.py
```

تغطي: التسجيل في الـ Registry، قراءة الإعدادات، إنشاء الـ Provider،
الاستجابة عبر MockModel، والتعامل مع الأخطاء (مسار مفقود، مهلة زمنية، backend غير متاح).
لا يُحمَّل أي موديل حقيقي في الاختبارات.

## التوسعة

- **backend جديد:** أضف كلاس backend في `custom.py` ثم سجّله في `registry.py`.
- **fine-tuning / LoRA:** حمّل الموديل عبر transformers ومرّر `peft` kwargs —
  نقطة التوسع موجودة في `_TransformersBackend`.
